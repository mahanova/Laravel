<?php

use Illuminate\Database\Seeder;

class InformasiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         DB::table('informasi')->insert(
        	[
        		'nama_perusahaan' => 'ASIATRACKS',
        		'telepon' => '(0274)-555-567',
        		'alamat' => 'Jalan Ki.Mangung Soebroto',
        		'email' => 'asiatracks@mail.com'
        	]
        );
    }
}
