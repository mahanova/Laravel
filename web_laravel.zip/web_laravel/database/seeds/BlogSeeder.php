<?php

use Illuminate\Database\Seeder;

class BlogSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('blog')->insert([
        	[
        		'judul' => 'Bali',
        		'isi' => 'Bali adalah salah satu provinsi di Indonesia',
        		'penulis' => 'Kadek Devi',
        		'gambar' => 'bali.jpg'
        	],

        	[
        		'judul' => 'Jogja',
        		'isi' => 'Jogja adalah salah satu provinsi di Indonesia',
        		'penulis' => 'Wong Jowo',
        		'gambar' => 'jogja.jpg'
        	],

        	[
        		'judul' => 'Solo',
        		'isi' => 'Solo adalah salah satu kota di Indonesia',
        		'penulis' => 'Wong Jowo',
        		'gambar' => 'solo.jpg'
        	],

        	[
        		'judul' => 'Jakarta',
        		'isi' => 'Jakarta ibukota negara Indonesia',
        		'penulis' => 'Wong Jowo',
        		'gambar' => 'jakarta.jpg'
        	],

        	[
        		'judul' => 'Palembang',
        		'isi' => 'palembang adalah salah satu kota di Indonesia',
        		'penulis' => 'Kadek Devi',
        		'gambar' => 'palembang.jpg'
        	],

        	[
        		'judul' => 'Bandung',
        		'isi' => 'Bandung adalah salah satu kota di Indonesia',
        		'penulis' => 'Kadek Devi',
        		'gambar' => 'bandung.jpg'
        	]
        ]);
    }
}
