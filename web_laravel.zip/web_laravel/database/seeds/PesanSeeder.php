<?php

use Illuminate\Database\Seeder;

class PesanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('pesan')->insert(
        	[
        		'nama' => 'Joko',
        		'email' => 'joko@mail.com',
        		'topik' => 'Transportasi',
        		'isi_pesan' => 'kira-kira, transportasi apa yang nyaman digunakan untuk berkeliling ke Bali?'
        	]
        );
    }
}
