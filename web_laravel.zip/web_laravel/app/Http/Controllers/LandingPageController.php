<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class LandingPageController extends Controller
{

	protected $table = 'informasi';

    public function index()
    {
    	$slider = DB::table('blog')->orderBy('id','asc')->limit(3)->get();
    	$datainformasi = DB::table('informasi')->first();

    	//count
    	$count = DB::table('blog')->count();
    	$data = DB::table('blog')->orderBy('id','desc')->limit($count-3)->get();

    	$all = DB::table('blog')->get();

    	return view('landingpage',['data'=>$data, 'slider'=>$slider, 'all'=>$all, 'informasi'=>$datainformasi]);
    }

    public function halaman($id)
    {
    	$slider = DB::table('blog')->orderBy('id','asc')->limit(3)->get();
    	$datainformasi = DB::table('informasi')->first();

    	
    	$all = DB::table('blog')->get();

    	$data = DB::table('blog')->where('id',$id)->first();


    	return view('halaman',['data'=>$data,'all'=>$all, 'slider'=>$slider, 'informasi'=>$datainformasi]);

    	
    }
}
