<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class InformasiController extends Controller
{
    //
    public function index()
    {
    	$data = DB::table('informasi')->get();
    	$count = DB::table('informasi')->count();

    	return view('admin/informasi', ['data'=>$data,'count'=>$count]);
    }

    public function detail($id)
    {
    	$data = DB::table('informasi')->where('id',$id)->first();

    	return view('admin/informasi_detail', ['data'=>$data]);
    }

    public function edit($id)
    {

    	$data = DB::table('informasi')->where('id',$id)->first();

    	return view("admin/informasi_edit",['data'=>$data]);
    }

    public function edit_proses(Request $request, $id)
    {
     	$data = DB::table('informasi')->where('id',$id)->first();
        $nama_perusahaan = $request->nama_perusahaan;
        $alamat = $request->alamat;
        $telepon = $request->telepon;
        $email = $request->email;
        $facebook = $request->facebook;
        $instagram = $request->instagram;
        $twitter = $request->twitter;

        DB::table('informasi')->where('id',$id)->update([
    			'nama_perusahaan' => $request->nama_perusahaan,
    			'alamat' => $alamat,
    			'telepon' => $telepon,
    			'email' => $email,
    			'facebook' => $facebook,
    			'instagram' => $instagram,
    			'twitter' => $twitter,
    		]);
        return redirect('admin/informasi')->with('sukses','Data berhasil diubah');
    }

    public function tambah()
    {
    	return view('admin/informasi_tambah');
    }

    public function tambah_proses(Request $request)
    {

        $nama_perusahaan = $request->nama_perusahaan;
        $alamat = $request->alamat;
        $telepon = $request->telepon;
        $email = $request->email;
        $facebook = $request->facebook;
        $instagram = $request->instagram;
        $twitter = $request->twitter;

        
            DB::table('informasi')->insert([
    			'nama_perusahaan' => $request->nama_perusahaan,
    			'alamat' => $alamat,
    			'telepon' => $telepon,
    			'email' => $email,
    			'facebook' => $facebook,
    			'instagram' => $instagram,
    			'twitter' => $twitter,
    		]);

    	return redirect('admin/informasi')->with('sukses','Data berhasil ditambahkan');

    }

     public function hapus($id)
    {
    	// hapus data
		DB::table('informasi')->where('id',$id)->delete();
 
		return redirect()->back()->with('sukses','Data berhasil dihapus');
    }



}
