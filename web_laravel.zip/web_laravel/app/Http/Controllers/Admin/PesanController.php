<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PesanController extends Controller
{
    public function index()
    {

    	$data = DB::table('pesan')->get();
    	return view('admin/pesan',['data'=>$data]);
    }

    public function hapus($id)
    {
		// hapus data
		DB::table('pesan')->where('id',$id)->delete();
 
		return redirect()->back()->with('sukses','Data berhasil dihapus');
    }

    public function detail($id)
    {
    	$data = DB::table('pesan')->where('id',$id)->first();

    	return view('admin/pesan_detail', ['data'=>$data]);
    }

}
