<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Storage;

use Illuminate\Support\Facades\DB;

class BlogController extends Controller
{
    public function index()
    {
    	$datablog = DB::table('blog')->get();

    	return view('admin/blog',['datablog'=>$datablog]);
    }

    public function tambah()
    {
    	return view('admin/blog_tambah');
    }

    public function tambah_proses(Request $request)
    {

    	$judul = $request->judul;
        $isi = $request->isi;
        $penulis = $request->penulis;

        
    	 if($request->hasFile('gambar'))
    	 {
            $resorce	= $request->file('gambar');
            $name   	= $resorce->getClientOriginalName();
            $resorce->move(\base_path() ."/public/gambar", $name);
            
            DB::table('blog')->insert([
    			'judul' => $judul,
    			'isi' => $isi,
    			'penulis' => $penulis,
    			'gambar' => $name
    		]);

    		return redirect('admin/blog')->with('sukses','Data berhasil ditambahkan');

        }else{
            
            return redirect('admin/blog')->with('gagal','Data gagal diupdate');
        }
    }


    public function edit($id)
    {

    	$data = DB::table('blog')->where('id',$id)->first();

    	return view("admin/blog_edit",['data'=>$data]);
    }

    public function edit_proses(Request $request, $id)
    {
     	$data = DB::table('blog')->where('id',$id)->first();
        $judul = $request->judul;
        $isi = $request->isi;
        $penulis = $request->penulis;

        if($request->file('gambar') == "")
        {
            $gambarku = $data->gambar;
        } 
        else
        {

            $file       = $request->file('gambar');
            $gambarku   = $file->getClientOriginalName();
            $file->move(\base_path() ."/public/gambar", $gambarku);
        }

        DB::table('blog')->where('id',$id)->update([
    			'judul' => $judul,
    			'isi' => $isi,
    			'penulis' => $penulis,
    			'gambar' => $gambarku
    		]);
        return redirect('admin/blog')->with('sukses','Data berhasil diubah');
    }

    public function hapus($id)
    {
    	$data = DB::table('blog')->where('id',$id)->first();

    	if($data->gambar == "")
    	{
			Storage::delete(public_path().'/gambar/'.$data->gambar);
 		}
		// hapus data
		DB::table('blog')->where('id',$id)->delete();
 
		return redirect()->back()->with('sukses','Data berhasil dihapus');
    }

    public function detail($id)
    {
    	$data = DB::table('blog')->where('id',$id)->first();
    	return view('admin/blog_detail',['data'=>$data]);
    }
}
