<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class KontakController extends Controller
{
	protected $table = 'pesan';

	public function index()
	{
        $datainformasi = DB::table('informasi')->first();

        $all = DB::table('blog')->get();

		return view('kontak',['informasi'=>$datainformasi, 'all'=>$all]);
	}

	public function tambah(Request $request)
    {
        
            DB::table('pesan')->insert([
                'nama' => $request->nama,
                'topik' => $request->topik,
                'email' => $request->email,
                'isi_pesan' => $request->isi_pesan,
            ]);

        return redirect()->back()->with('sukses','Pesan anda terkirim');

    }
    
}
