<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Informasi extends Model
{
	protected $table = 'informasi';
    protected $fillable = ['nama_perusahaan','telepon' , 'alamat', 'email', 'facebook', 'twitter', 'instagram'];
}
